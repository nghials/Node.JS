var express = require("express");
var app = express();
var path = require('path');
var server = require("http").Server(app);
var io = require("socket.io")(server);
app.use('/public',express.static(path.join(__dirname,'public')));
server.listen(80);

users = [];
connections = [];


app.get('/', function(req,res){
	res.sendFile(__dirname + "/index.html");
});

io.on("connection", function(socket){
	connections.push(socket);
	console.log("Connected : socket connected!", connections.length);


	socket.on("disconnect", function(data){
		users.splice(users.indexOf(socket.username),1);
		updateUser();
		connections.splice(connections.indexOf(socket),1);
		console.log("Disconnected : socket connected", connections.length);
	});


	socket.on("sendmessage", function(data){
		io.emit("newmessage",{message:data, user:socket.username});
	});

	socket.on("newuser", function(data,callback){
		if(users.indexOf(data) != -1){
			callback(false);
		}else{
			callback(true);
			socket.username = data;
			users.push(socket.username);
			updateUser();
		}
	});

	function updateUser(){
		io.emit("updateUser", users);
	}
});